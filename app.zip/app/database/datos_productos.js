class productos {
  constructor() {
    this.lista =  [
      {
        id: 1,
        nombre_producto: "computador",
        valor_producto: 15000000,
        expiracion_producto: "2022-12-31",
        categoria_producto: "Electronico",
        descripcion_producto: "This is product "
      },
      {
        id: 2,
        nombre_producto: "lavadora",
        valor_producto: 10000,
        expiracion_producto: "2022-12-31",
        categoria_producto: "Electrodomestico",
        descripcion_producto: "This is product "
      },
      {
        id: 3,
        nombre_producto: "nevera",
        valor_producto: 1200000,
        expiracion_producto: "2022-12-31",
        categoria_producto: "Electrodomestico",
        descripcion_producto: "This is product "
      },
      {
        id: 4,
        nombre_producto: "licuadora",
        valor_producto: 120000,
        expiracion_producto: "2022-12-31",
        categoria_producto: "Electrodomestico",
        descripcion_producto: "This is product "
      },
      {
        id: 5,
        nombre_producto: "sofa",
        valor_producto: 1300000,
        expiracion_producto: "2022-12-31",
        categoria_producto: "Electrodomestico",
        descripcion_producto: "This is product "
      },
      {
        id: 6,
        nombre_producto: "horno",
        valor_producto: 800000,
        expiracion_producto: "2022-12-31",
        categoria_producto: "Electrodomestico",
        descripcion_producto: "This is product "
      },
      {
        id: 7,
        nombre_producto: "play 5",
        valor_producto: 5000000,
        expiracion_producto: "2022-12-31",
        categoria_producto: "Electrodomestico",
        descripcion_producto: "This is product "
      },
      {
        id: 8,
        nombre_producto: "iphone 15",
        valor_producto: 6500000,
        expiracion_producto: "2022-12-31",
        categoria_producto: "Electronico",
        descripcion_producto: "This is product "
      },
      {
        id: 9,
        nombre_producto: "picador",
        valor_producto: 140000,
        expiracion_producto: "2024-12-21",
        categoria_producto: "Electrodomestico",
        descripcion_producto: "This is product "
      },
      {
        id: 10,
        nombre_producto: "freidora de aire",
        valor_producto: 140000,
        expiracion_producto: "2024-12-21",
        categoria_producto: "Electrodomestico",
        descripcion_producto: "This is product "
      },
      {
        id: 11,
        nombre_producto: "pitadora",
        valor_producto: 150000,
        expiracion_producto: "2024-12-21",
        categoria_producto: "utencilios de cocina",
        descripcion_producto: "This is product "
      },
      {
        id: 12,
        nombre_producto: "exprimidor de naranjas",
        valor_producto: 150000,
        expiracion_producto: "2024-12-21",
        categoria_producto: "utencilios de cocina",
        descripcion_producto: "This is product "
      },
      {
        id: 13,
        nombre_producto: "juego de cuchillos",
        valor_producto: 180000,
        expiracion_producto: "2024-12-21",
        categoria_producto: "utencilios de cocina",
        descripcion_producto: "This is product "
      },
      {
        id: 14,
        nombre_producto: "camara",
        valor_producto: 190000,
        expiracion_producto: "2024-12-21",
        categoria_producto: "electronico",
        descripcion_producto: "This is product "
      },
      {
        id: 15,
        nombre_producto: "armario",
        valor_producto: 900000,
        expiracion_producto: "2022-12-31",
        categoria_producto: "muebles",
        descripcion_producto: "This is product "
      }
    ];
  }


}
module.exports = productos;
