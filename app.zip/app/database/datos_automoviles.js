class automoviles {
  constructor() {
    this.lista =  [
      {
        id: 1,
        marca: "Toyota",
        cilindraje: 2000,
        tipo: "Gasolina",
        linea: "Corolla",
        color: "Blanco",
        placa: "ABC123",
        precio:50000000
      },
      {
        id: 2,
        marca: "Honda",
        cilindraje: 1500,
        tipo: "Hibrido",
        linea: "Civic",
        color: "Negro",
        placa: "DEF456",
        precio:50000000
      },
      {
        id: 3,
        marca: "Tesla",
        cilindraje: 3000,
        tipo: "Eléctrico",
        linea: "Model 3",
        color: "Gris",
        placa: "GHI789",
        precio:163000000
      },
      {
        id: 4,
        marca: "Ford",
        cilindraje: 2500,
        tipo: "Gasolina",
        linea: "Fusion",
        color: "Rojo",
        placa: "JKL012",
        precio:159000000
      },
      {
        id: 5,
        marca: "Nissan",
        cilindraje: 1800,
        tipo: "Gasolina",
        linea: "Sentra",
        color: "Azul",
        placa: "MNO345",
        precio:53000000
      },
      {
        id: 6,
        marca: "Volkswagen",
        cilindraje: 2000,
        tipo: "Diesel",
        linea: "Golf",
        color: "Verde",
        placa: "PQR678",
        precio:140000000
      },
      {
        id: 7,
        marca: "Chevrolet",
        cilindraje: 3000,
        tipo: "Gasolina",
        linea: "Camaro",
        color: "Amarillo",
        placa: "STU901",
        precio:153000000
      },
      {
        id: 8,
        marca: "Kia",
        cilindraje: 1500,
        tipo: "Gasolina",
        linea: "Rio",
        color: "Gris",
        placa: "VWX234",
        precio:43000000
      },
      {
        id: 9,
        marca: "Hyundai",
        cilindraje: 2000,
        tipo: "Gasolina",
        linea: "Elantra",
        color: "Blanco",
        placa: "YZA567",
        precio:54000000
      },
      {
        id: 10,
        marca: "Mazda",
        cilindraje: 2500,
        tipo: "Gasolina",
        linea: "3",
        color: "Rojo",
        placa: "BCD890",
        precio:153000000
      },
      {
        id: 11,
        marca: "Audi",
        cilindraje: 2700,
        tipo: "Gasolina",
        linea: "32",
        color: "Gris",
        placa: "BCD890",
        precio:133000000
      },
      {
        id: 12,
        marca: "Mazda",
        cilindraje: 2500,
        tipo: "Hibrido",
        linea: "31",
        color: "Rojo",
        placa: "JCD890",
        precio:183000000
      },
      {
        id: 13,
        marca: "Tesla",
        cilindraje: 2900,
        tipo: "Electrico",
        linea: "3",
        color: "Rojo",
        placa: "BJH800",
        precio:193000000
      },
      {
        id: 14,
        marca: "Mazda",
        cilindraje: 2600,
        tipo: "Gasolina",
        linea: "3",
        color: "Rojo",
        placa: "HYD890",
        precio:113000000
      },{
        id: 15,
        marca: "Toyota",
        cilindraje: 2600,
        tipo: "Gasolina",
        linea: "3",
        color: "Rojo",
        placa: "BLK989",
        precio:123000000
      }
    ];
  }



}
module.exports = automoviles;
